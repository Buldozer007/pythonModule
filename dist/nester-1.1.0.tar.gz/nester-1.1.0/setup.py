from distutils.core import setup

setup(
    name = "nester",
    version  = "1.1.0",
    py_modules = ['nester'],
    author = 'Suren',
    author_email = 'sur0363@ro.ru',
    url = "https://www.google.com/",
    descripton = 'A simple printer of nested lists'
    )