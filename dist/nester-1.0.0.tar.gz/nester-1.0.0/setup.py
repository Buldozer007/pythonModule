from distutils.core import setup

setup(
    name = "nester",
    version  = "1.0.0",
    py_modules = ['nester'],
    author = 'Suren',
    author_email = 'sur0363@ro.ru',
    url = "-",
    descripton = 'A simple printer of nested lists'
    )